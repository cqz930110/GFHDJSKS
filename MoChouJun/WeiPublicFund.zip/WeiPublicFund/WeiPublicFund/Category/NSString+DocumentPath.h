//
//  NSString+DocumentPath.h
//  WeiPublicFund
//
//  Created by liuyong on 15/12/18.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (DocumentPath)
+(NSString *)documentPathWith:(NSString *)fileName;
@end

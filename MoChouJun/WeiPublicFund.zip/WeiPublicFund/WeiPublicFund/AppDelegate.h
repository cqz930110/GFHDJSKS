//
//  AppDelegate.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/11/26.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TabBarController;
@class LoginViewController;
#define kLoadContactTime @"kLoadContactTime"

@interface AppDelegate : UIResponder <UIApplicationDelegate, IChatManagerDelegate>
{
    EMConnectionState _connectionState;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) TabBarController *mainController;
@property (strong, nonatomic) NSDate *lastPlaySoundDate;
@end


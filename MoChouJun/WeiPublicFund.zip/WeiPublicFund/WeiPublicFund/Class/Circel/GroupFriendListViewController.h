//
//  GroupFriendListViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/26.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface GroupFriendListViewController : BaseViewController
@property (copy, nonatomic) NSString *groupId;
@end

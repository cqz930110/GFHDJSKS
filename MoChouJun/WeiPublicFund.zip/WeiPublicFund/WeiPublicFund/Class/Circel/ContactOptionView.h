//
//  ContactOptionView.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/2.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AddFriendViewController;
@interface ContactOptionView : UIView
@property (weak, nonatomic)  AddFriendViewController *delegate;
@end

//
//  GroupNotice.m
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/17.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "GroupNotice.h"

@implementation GroupNotice

@end

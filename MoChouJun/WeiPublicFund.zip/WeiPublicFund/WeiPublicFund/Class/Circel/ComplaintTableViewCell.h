//
//  ComplaintTableViewCell.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/12.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComplaintTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *complaintTitleLab;
@property (weak, nonatomic) IBOutlet UIImageView *complaintSelectImageView;

@end

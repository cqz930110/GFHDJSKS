//
//  GroupFriendSelectTableViewCell.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/16.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class PSBuddy;

@interface GroupFriendSelectTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *peopleImageView;
@property (weak, nonatomic) IBOutlet UILabel *peopleNameLab;
@property (weak, nonatomic) IBOutlet UIImageView *selectImageView;

@property (nonatomic,strong)PSBuddy *buddy;
@end

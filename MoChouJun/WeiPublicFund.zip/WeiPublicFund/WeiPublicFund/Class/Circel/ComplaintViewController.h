//
//  ComplaintViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/4.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface ComplaintViewController : BaseViewController
@property (copy, nonatomic) NSString *username;
@property (copy, nonatomic) NSString *complaintType;

@end

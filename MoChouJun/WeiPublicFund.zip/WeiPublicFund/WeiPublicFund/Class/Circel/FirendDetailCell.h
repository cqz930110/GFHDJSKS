//
//  FirendDetailCell.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/3.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Project;
@interface FirendDetailCell : UITableViewCell
@property (strong, nonatomic) Project *project;
@end

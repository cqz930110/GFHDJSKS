//
//  TongXunLuCommonTableViewCell.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/13.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TongXunLuCommonTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *numberLab;

@end

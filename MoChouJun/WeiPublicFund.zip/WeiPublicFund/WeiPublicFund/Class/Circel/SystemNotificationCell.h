//
//  SystemNotificationCell.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/4.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SystemMessage;
@interface SystemNotificationCell : UITableViewCell
@property (strong, nonatomic) SystemMessage *message;
+ (CGFloat)contentHeightContentString:(NSString *)message;
@end

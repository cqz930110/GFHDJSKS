//
//  BlackBuddy.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/18.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BlackBuddy : NSObject
/// 好友关系Id
@property (assign, nonatomic) long Id;
/// 好友的用户Id
@property (assign, nonatomic) long userId;
/// 昵称
@property (copy, nonatomic) NSString *nickName;
/// 图像
@property (copy, nonatomic) NSString *avatar;

/// 昵称
@property (copy, nonatomic) NSString *userName;

/**
 *  展示文字
 */
@property (copy, nonatomic) NSString *notes;
- (NSString *)reviewName;
@end

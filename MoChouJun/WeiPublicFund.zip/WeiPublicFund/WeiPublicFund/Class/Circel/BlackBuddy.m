//
//  BlackBuddy.m
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/18.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BlackBuddy.h"

@implementation BlackBuddy
- (NSString *)reviewName
{
    if (_notes.length > 0)
    {
        return _notes;
    }
    else if (_nickName.length > 0)
    {
        return _nickName;
    }
    else
    {
        return _userName;
    }
}
@end

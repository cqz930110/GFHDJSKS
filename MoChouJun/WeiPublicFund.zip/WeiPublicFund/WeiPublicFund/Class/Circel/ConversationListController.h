//
//  ConversationListController.h
//  ChatDemo-UI3.0
//
//  Created by dhc on 15/6/25.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//
#import "GroupListViewController.h"
@interface ConversationListController : EaseConversationListViewController
- (void)refreshDataSource;
- (void)isConnect:(BOOL)isConnect;
- (void)networkChanged:(EMConnectionState)connectionState;

//群组变化时，更新群组页面 --> 针对项目组
- (void)reloadGroupView;
@end

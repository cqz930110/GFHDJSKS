//
//  ComplaintTableViewCell.m
//  WeiPublicFund
//
//  Created by liuyong on 16/6/12.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "ComplaintTableViewCell.h"

@implementation ComplaintTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    if (selected)
    {
        _complaintSelectImageView.hidden = NO;
    }
    else
    {
        _complaintSelectImageView.hidden = YES;
    }
}

@end

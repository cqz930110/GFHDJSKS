//
//  ContactOptionView.m
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/2.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "ContactOptionView.h"
#import "AddFriendViewController.h"
@implementation ContactOptionView
- (IBAction)gotoPhoneContact:(UIButton *)sender
{
    if ([self.delegate respondsToSelector:@selector(gotoPhoneContact)])
    {
        [self.delegate gotoPhoneContact];
    }
}

@end

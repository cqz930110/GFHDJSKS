//
//  PSGroup.m
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/18.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "PSGroup.h"

@implementation PSGroup

@end

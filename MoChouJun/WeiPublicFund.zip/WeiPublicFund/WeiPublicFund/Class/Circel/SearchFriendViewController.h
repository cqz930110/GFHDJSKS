//
//  SearchFriendViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/2.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface SearchFriendViewController : BaseViewController

@end

//
//  NewAddFriendCollectionViewCell.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/30.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewAddFriendCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *addImageView;
- (void)setimageUrl:(NSString *)imageUrl;
@end

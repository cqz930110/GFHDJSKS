//
//  PSChatGroupDetailViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/17.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"
typedef enum{
    PSGroupOccupantTypeOwner,//创建者
    PSGroupOccupantTypeMember,//成员
}PSGroupOccupantType;
@interface PSChatGroupDetailViewController : BaseViewController
@property (copy, nonatomic) NSString *groupId;

@end

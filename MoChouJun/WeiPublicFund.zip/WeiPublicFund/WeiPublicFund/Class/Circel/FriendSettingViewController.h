//
//  FriendSettingViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/21.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"
@interface FriendSettingViewController : BaseViewController

/**
 *  只需要传这两个个就👌
 */
@property (copy, nonatomic) NSString *friendId;
@property (copy, nonatomic) NSString *username;

@property (nonatomic,assign) NSInteger friendYesOrNo;

@property (nonatomic,copy) NSString *notes;
@end

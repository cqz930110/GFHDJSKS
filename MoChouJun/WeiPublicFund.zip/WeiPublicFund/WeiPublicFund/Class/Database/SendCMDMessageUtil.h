//
//  SendCMDMessageUtil.h
//  WeiPublicFund
//
//  Created by Apple on 16/4/2.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SendCMDMessageUtil : NSObject
+ (void)sendAvatarCMDMEessage:(NSString *)avatar;
+ (void)sendNicknameCMDMEessage:(NSString *)name;
+ (void)sendGroupNameCMDEessage:(NSString *)name groupId:(NSString *)groupId;
+ (void)sendGroupAvatarCMDEessage:(NSString *)avatar groupId:(NSString *)groupId;


+ (void)sendChatApplyMessageReceiveUsername:(NSString *)username;
+ (void)sendGroupApplyMessageGroupId:(NSString *)groupId message:(NSString *)messageText;
+ (EMMessage *)sendGroupNoticeMessageGroupId:(NSString *)groupId message:(NSString *)messageText;
@end

//
//  AbountWeViewController.h
//  PublicFundraising
//
//  Created by liuyong on 15/10/14.
//  Copyright © 2015年 Niuduz. All rights reserved.
//

#import "BaseViewController.h"

@interface AbountWeViewController : BaseViewController

@end

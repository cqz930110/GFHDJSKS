//
//  GroupListsViewController.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/14.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface GroupListsViewController : BaseViewController

- (void)reloadDataSource;
@property (assign, nonatomic) int groupType;//项目组为 1  普通的为0
@end

//
//  CustomMessageCell.h
//  ChatDemo-UI3.0
//
//  Created by EaseMob on 15/8/26.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//

@interface CustomMessageCell : EaseBaseMessageCell

@end

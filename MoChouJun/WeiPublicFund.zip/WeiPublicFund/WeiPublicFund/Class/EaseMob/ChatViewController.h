//
//  ChatViewController.h
//  ChatDemo-UI3.0
//
//  Created by dhc on 15/6/26.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//


#define KNOTIFICATIONNAME_DELETEALLMESSAGE @"RemoveAllMessages"
@class PSGroup;
@interface ChatViewController : EaseMessageViewController
@property (strong, nonatomic) PSGroup *group;// 群组参数
@property (strong, nonatomic) EaseConversationModel *model;
@property (assign, nonatomic) BOOL isProjectChat;
@end

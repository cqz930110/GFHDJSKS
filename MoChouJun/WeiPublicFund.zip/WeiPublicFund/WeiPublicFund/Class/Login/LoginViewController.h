//
//  LoginViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 15/11/26.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController
@end

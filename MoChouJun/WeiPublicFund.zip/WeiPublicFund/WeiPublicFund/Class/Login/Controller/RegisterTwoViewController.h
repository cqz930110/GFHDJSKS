//
//  RegisterTwoViewController.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface RegisterTwoViewController : BaseViewController

@property (strong, nonatomic) NSMutableDictionary *registerDic;
@end

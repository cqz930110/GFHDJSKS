//
//  ResetPsdOneViewController.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ResetPsdOneViewController : BaseViewController
@property (copy, nonatomic) NSString *mobile;
@property (strong, nonatomic) NSMutableDictionary *passwordDic;
@property (copy, nonatomic) NSString *statuCode;
@end

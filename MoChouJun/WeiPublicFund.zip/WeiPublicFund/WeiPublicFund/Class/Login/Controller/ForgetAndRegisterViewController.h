//
//  ForgetAndRegisterViewController.h
//  NT
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 Pem. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ForgetAndRegisterViewController : BaseViewController
@end

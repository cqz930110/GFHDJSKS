//
//  ResetPsdTwoViewController.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface ResetPsdTwoViewController : BaseViewController
@property (strong, nonatomic) NSMutableDictionary *passwordDic;
@end

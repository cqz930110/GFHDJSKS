//
//  RegisterOneViewController.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface RegisterOneViewController : BaseViewController
@property (copy, nonatomic) NSString *mobile;
@property (copy, nonatomic) NSString *valicateCode;
@property (strong, nonatomic) NSMutableDictionary *registerDic;

@end

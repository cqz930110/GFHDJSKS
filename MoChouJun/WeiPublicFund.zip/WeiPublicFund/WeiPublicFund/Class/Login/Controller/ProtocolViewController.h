//
//  ProtocolViewController.h
//  WeiPublicFund
//
//  Created by liuyong on 16/1/18.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface ProtocolViewController : BaseViewController

@end

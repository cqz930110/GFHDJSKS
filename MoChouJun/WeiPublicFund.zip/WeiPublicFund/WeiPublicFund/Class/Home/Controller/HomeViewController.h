//
//  HomeViewController.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import "BaseViewController.h"

@class CircleTableViewCell;
@class ProjectTableViewCell;
@interface HomeViewController : BaseViewController
@property (strong, nonatomic) NSArray *conversations;


////  CircleTableViewCell delegate
//- (void)circleTableViewCell:(CircleTableViewCell *)cell supportProject:(id)project;
//
////  CircleTableViewCell delegate
//- (void)circleFontTableViewCell:(CircleTableViewCell *)cell supportProject:(id)project;
//
////  CircleTableViewCell delegate
- (void)projectTableViewCell:(ProjectTableViewCell *)cell supportProject:(id)project;

@end

//
//  McjHomeViewController.h
//  WeiPublicFund
//
//  Created by liuyong on 16/6/2.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface McjHomeViewController : UIViewController

@end

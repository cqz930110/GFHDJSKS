//
//  AdDetailViewController.h
//  WeiPublicFund
//
//  Created by zhoupushan on 16/4/19.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "BaseViewController.h"

@interface AdDetailViewController : BaseViewController
@property (copy, nonatomic) NSString *adDetailUrl;
@end

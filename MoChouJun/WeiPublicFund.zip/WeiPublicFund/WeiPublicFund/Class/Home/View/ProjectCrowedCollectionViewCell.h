//
//  ProjectCrowedCollectionViewCell.h
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Project;
@interface ProjectCrowedCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) Project *project;
@end

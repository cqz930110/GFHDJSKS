//
//  CircleTableViewCell.m
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import "CircleTableViewCell.h"
#import "HomeViewController.h"
#import "MessageScrollView.h"
@implementation CircleTableViewCell

- (void)awakeFromNib
{
    _messageIconBtn.layer.cornerRadius = 15.0f;
    _messageIconBtn.layer.masksToBounds = YES;// 10 43
}

#pragma mark click Circle
- (IBAction)circleClick:(id)sender
{
//    if ([self.delegate respondsToSelector:@selector(circleFontTableViewCell:supportProject:)]) {
//        [self.delegate circleFontTableViewCell:self supportProject:nil];
//    }
}

#pragma mark click user
- (IBAction)userIconClick:(id)sender
{
//    if ([self.delegate respondsToSelector:@selector(circleTableViewCell:supportProject:)]) {
////        [self.delegate circleTableViewCell:self supportProject:nil];
//    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end

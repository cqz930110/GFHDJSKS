//
//  ProjectCollectionViewCell.m
//  TipCtrl
//
//  Created by liuyong on 15/11/27.
//  Copyright © 2015年 hesong. All rights reserved.
//

#import "ProjectCollectionViewCell.h"
#import "NetWorkingUtil.h"

@implementation ProjectCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setImageUrl:(NSString *)imageUrl
{
    [NetWorkingUtil setImage:self.imageView url:imageUrl defaultIconName:@"home_默认"];
}

@end

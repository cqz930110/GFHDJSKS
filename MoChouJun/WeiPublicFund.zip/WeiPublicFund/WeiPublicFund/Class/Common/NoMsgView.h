//
//  NoMsgView.h
//  CunQiuDPro
//
//  Created by liuyong on 15/11/2.
//  Copyright (c) 2015年 NDZIOS01. All rights reserved.
//1

#import <UIKit/UIKit.h>

@interface NoMsgView : UIView
@property (weak, nonatomic) IBOutlet UILabel *showMsgLab;
@property (weak, nonatomic) IBOutlet UIImageView *showImageView;

@end

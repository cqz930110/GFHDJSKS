//
//  NoMsgView.m
//  CunQiuDPro
//
//  Created by liuyong on 15/11/2.
//  Copyright (c) 2015年 NDZIOS01. All rights reserved.
//

#import "NoMsgView.h"

@implementation NoMsgView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
     Drawing code
}
*/

@end

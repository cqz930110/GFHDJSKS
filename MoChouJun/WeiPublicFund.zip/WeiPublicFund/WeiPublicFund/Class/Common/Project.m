//
//  Project.m
//  WeiPublicFund
//
//  Created by zhoupushan on 15/12/7.
//  Copyright © 2015年 www.niuduz.com. All rights reserved.
//

#import "Project.h"
#import <YYModel.h>
@implementation Project
- (void)encodeWithCoder:(NSCoder *)aCoder { [self yy_modelEncodeWithCoder:aCoder]; }
- (id)initWithCoder:(NSCoder *)aDecoder { self = [super init]; return [self yy_modelInitWithCoder:aDecoder]; }
@end

//
//  PSActionSheet.h
//  PublicFundraising
//
//  Created by zhoupushan on 15/10/18.
//  Copyright © 2015年 Niuduz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSActionSheet : UIActionSheet

@end

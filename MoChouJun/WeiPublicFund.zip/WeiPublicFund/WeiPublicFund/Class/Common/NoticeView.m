//
//  NoticeView.m
//  WeiPublicFund
//
//  Created by liuyong on 16/3/28.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "NoticeView.h"

@implementation NoticeView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

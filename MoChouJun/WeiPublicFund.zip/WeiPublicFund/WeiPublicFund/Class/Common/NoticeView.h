//
//  NoticeView.h
//  WeiPublicFund
//
//  Created by liuyong on 16/3/28.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoticeView : UIView

@end

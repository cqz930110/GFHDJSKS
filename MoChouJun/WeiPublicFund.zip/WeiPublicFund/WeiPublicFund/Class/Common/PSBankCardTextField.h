//
//  PSBankCardTextField.h
//  WeiPublicFund
//
//  Created by zhoupushan on 16/2/24.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSBankCardTextField : UITextField

@end

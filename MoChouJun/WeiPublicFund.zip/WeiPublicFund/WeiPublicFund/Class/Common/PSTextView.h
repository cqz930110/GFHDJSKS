//
//  PSTextView.h
//  WeiPublicFund
//
//  Created by zhoupushan on 16/3/21.
//  Copyright © 2016年 www.niuduz.com. All rights reserved.
//

#import "IQTextView.h"

@interface PSTextView : IQTextView

@end
